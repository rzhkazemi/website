from django.contrib.sitemaps.views import sitemap


class PostListSitemap(sitemap.Sitemap):
    pass
