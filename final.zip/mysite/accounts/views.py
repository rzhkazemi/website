from django.shortcuts import render, redirect

from django.contrib.auth.forms import AuthenticationForm, UserCreationForm

from accounts.forms import signupform

from django.contrib.auth import authenticate, login, logout

from django.contrib.auth.models import User


from django.contrib.auth.decorators import login_required

from django.urls import reverse

from django.contrib import messages

from django.contrib.auth.views import PasswordResetView

from django.contrib.messages.views import SuccessMessageMixin

from django.urls import reverse_lazy

# Create your views here.


def Login_View(request):

    if not request.user.is_authenticated:

        if request.method == "POST":

            form = AuthenticationForm(request=request, data=request.POST)

            if form.is_valid():

                username = form.cleaned_data["username"]

                password = form.cleaned_data["password"]

                user = authenticate(username=username,
                                    password=password)

                if user is not None:

                    login(request, user)

                    return redirect('/')

        form = AuthenticationForm()

        return render(request, 'accounts/login.html')

    return redirect('/')


@login_required
def Logout_View(request):

    logout(request)

    return redirect('/')


def Signup_View(request):

    if not request.user.is_authenticated:

        if request.method == "POST":

            form = signupform(request.POST)

            if form.is_valid():

                data = form.cleaned_data

                User.objects.create_user(username=data['username'],

                                         email=data['email'],

                                         password=data['password1'])

                messages.success(request, 'successfully signed up', 'success')

                return render(request, 'accounts/welcome.html')

            messages.error(request, "failled to sign up", "error")

            return render(request, "accounts/signup.html", {"form": form})

        form = signupform()

        return render(request, "accounts/signup.html", {"form": form})


# class ResetPasswordView(SuccessMessageMixin, PasswordResetView):

#     template_name = 'accounts/password_reset.html'
#     email_template_name = 'accounts/password_reset_email.html'
#     subject_template_name = 'accounts/password_reset_subject.txt'
#     success_message = "We've emailed you instructions for setting your password, " \
#                       "if an account exists with the email you entered. You should receive them shortly." \
#                       " If you don't receive an email, " \
#                       "please make sure you've entered the address you registered with, and check your spam folder."
#     success_url = reverse_lazy('/')
